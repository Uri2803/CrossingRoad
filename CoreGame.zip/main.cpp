﻿#include <iostream>
#include "Music.h"
#include <fstream>
#include "Console.h"
using namespace std;
enum GameState { mainMenu, playMenu, optionMenu, loadGame, playGame, pauseMenu, credits, exitGame };
enum MovingDir { left_, right_, up_, down_, idle_ };

class Game : private MyConsole, private Music
{
	short bgColor;
	bool playing;
	GameState state;
	thread* scene;
public:
	Game() 
	{ 
		bgColor = COLOUR::BG_WHITE;
		playing = false;
		state = mainMenu;
	}
	Game(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE);
	void Start();
	~Game();
};
Game::Game(int width_, int height_, int fontSize, short color)
{
	BuildConsole(width_, height_, fontSize, color);
	playing = true;
	bgColor = color;

	for (int i = 0; i < getHeight(); i++) // draw something here
		for (int j = 0; j < getWidth(); j++)
			addChar(Position(j, i), L' ', bgColor);
}
Game::~Game()
{
	delete scene;
}
void Game::Start()
{
	playTheme();
	// drawing border, first frame to create border
	short borderColor = COLOUR::BG_WHITE | FG_DARK_GREEN;
	for (int y = 0; y < getHeight(); y++)
	{
		for (int x = 0; x < getWidth(); x++)
		{
			if (x == 0 && y == 0) // left top corner
				addChar(Position(x, y), L'╔', borderColor);
			else if (x == getWidth() - 1 && y == 0) // right top corner
				addChar(Position(x, y), L'╗', borderColor);
			else if (x == 0 && y == getHeight() - 1) // left low corner
				addChar(Position(x, y), L'╚', borderColor);
			else if (x == getWidth() - 1 && y == getHeight() - 1) // right low corner
				addChar(Position(x, y), L'╝', borderColor);
			else if (x == 0 || x == getWidth() - 1)
				addChar(Position(x, y), L'║', borderColor);
			else if (y == 0 || y == getHeight() - 1)
				addChar(Position(x, y), L'═', borderColor);
		}
	}

	int x = 5, y = 5, vel = 3;
	short carCol = bgColor | FG_RED;
	
	while (playing)
	{
		char key = getch();
		if (key == 'd')
		{
			playKeyBoardSound();
			x += vel;
			FillArea(Position(x - vel, y), L' ', car1.getWidth(), car1.getHeight(), bgColor);
		}
		if (key == 'a')
		{
			playKeyBoardSound();
			x -= vel;
			FillArea(Position(x + vel, y), L' ', car1.getWidth(), car1.getHeight(), bgColor);
		}
		if (key == 'w')
		{
			playKeyBoardSound();
			y -= vel;
			FillArea(Position(x, y + vel), L' ', car1.getWidth(), car1.getHeight(), bgColor);
		}
		if (key == 's')
		{
			playKeyBoardSound();
			y += vel;
			FillArea(Position(x, y - vel), L' ', car1.getWidth(), car1.getHeight(), bgColor);
		}
		drawPicture(x, y, car1, carCol);
		drawConsole(); // the main thing we need
	}
}
int main()
{
	SetConsoleTitle(TEXT("CROSSING ROAD GROUP 4"));
	Game game = Game(210, 49, 16, COLOUR::BG_WHITE);
	game.Start();
}