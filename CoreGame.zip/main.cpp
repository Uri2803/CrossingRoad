﻿#include <iostream>
#include "Console.h"
using namespace std;
class Game : private MyConsole
{
	CHAR_INFO** tile;
	short bgColor;
	bool playing;
public:
	Game() { }
	Game(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE);
	void LoadToScreenBuffer();
	void PlayGame();
	void clearArea(Position pos, int width, int height);
	~Game();
};
void Game::clearArea(Position pos, int width, int height)
{
	for (int i = 0; i < height; i++)
		for (int j = 0; j < width; j++)
		{
			tile[i + pos.y][j + pos.x].Char.UnicodeChar = ' ';
			tile[i + pos.y][j + pos.x].Attributes = bgColor;
		}
}
Game::Game(int width_, int height_, int fontSize, short color)
{
	BuildConsole(width_, height_, fontSize, color);
	tile = new CHAR_INFO * [height_];
	for (int i = 0; i < height_; i++)
	{
		tile[i] = new CHAR_INFO[width_];
		for (int j = 0; j < width_; j++)
		{
			tile[i][j].Char.UnicodeChar = ' ';
			tile[i][j].Attributes = color;
		}
	}
	playing = true;
	bgColor = color;

	for (int i = 0; i < getHeight(); i++) // draw something here
		for (int j = 0; j < getWidth(); j++)
		{
			tile[i][j].Char.UnicodeChar = ' ';
			tile[i][j].Attributes = color;
		}
	LoadToScreenBuffer();
}
Game::~Game()
{
	delete[]tile;
}
void Game::LoadToScreenBuffer() // load everything inside the map to the buffer
{
	for (int i = 0; i < getHeight(); i++)
		for (int j = 0; j < getWidth(); j++)
			addToBuffer(tile[i][j], Position(j, i)); // load 1 tile to the buffer
}
void Game::PlayGame()
{
	// drawing border
	short borderColor = COLOUR::BG_WHITE | FG_DARK_GREEN;
	for (int i = 0; i < getHeight(); i++)
	{
		for (int j = 0; j < getWidth(); j++)
		{
			if (i == 0 && j == 0) // left top corner
			{
				tile[i][j].Char.UnicodeChar = L'╔';
				tile[i][j].Attributes = borderColor;
			}
			else if (j == getWidth() - 1 && i == 0) // right top corner
			{
				tile[i][j].Char.UnicodeChar = L'╗';
				tile[i][j].Attributes = borderColor;
			}
			else if (j == 0 && i == getHeight() - 1) // left low corner
			{
				tile[i][j].Char.UnicodeChar = L'╚';
				tile[i][j].Attributes = borderColor;
			}
			else if (j == getWidth() - 1 && i == getHeight() - 1) // right low corner
			{
				tile[i][j].Char.UnicodeChar = L'╝';
				tile[i][j].Attributes = borderColor;
			}
			else if (j == 0 || j == getWidth() - 1)
			{
				tile[i][j].Char.UnicodeChar = L'║';
				tile[i][j].Attributes = borderColor;
			}
			else if (i == 0 || i == getHeight() - 1)
			{
				tile[i][j].Char.UnicodeChar = L'═';
				tile[i][j].Attributes = borderColor;
			}
		}
	}
	LoadToScreenBuffer();
	int x = 5, y = 5;
	short carCol = bgColor | FG_RED;
	while (playing)
	{
		char key = getch();
		if (key == 'd')
		{
			x++;
			for (int i = 0; i < car1.getHeight(); i++)
			{
				wstring space = L" ";
				for (int j = 0; j < car1.getWidth(); j++)
					space += ' ';
				drawString(x - 1, y + i, space, carCol);
			}
			// clearArea(Position(x - 1, y), car1.getWidth(), car1.getHeight());
		}
		drawPicture(x, y, car1, carCol);
		drawConsole(); // the main thing we need
	}
}
int main()
{
	SetConsoleTitle(TEXT("CROSSING ROAD GROUP 4"));
	Game game = Game(210, 49, 16, COLOUR::BG_WHITE);
	game.PlayGame();
}