﻿#include "Game.h"
bool main()
{
	SetConsoleTitle(TEXT("CROSSING ROAD GROUP 4"));
	Game game = Game(210, 49, 16, COLOUR::BG_WHITE);
	game.Start();
}