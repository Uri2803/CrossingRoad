#pragma once
#ifndef _OBJECT
#define _OBJECT_
#include "Animation.h"

enum MovingDir { left_, right_, up_, down_, idle_ }; // for moving I think :3
class Object : public Position
{
protected:
	Animation anim;
public:
	picture curImg() const { return anim.getCurFrame(); }
	picture preImg() const { return anim.getPreFrame(); }
	void setAnim(const Animation);
	short getColor() { return anim.getCol(); }
	void playAnim();
};
class MovingObject : public Object
{
protected:
	int vel, mov_count, mov_timer;
	MovingDir direction;
public:
	bool is_moving;
	MovingObject() 
	{ 
		mov_count = mov_timer = 100; 
		is_moving = true;
	}
	int velocity() { return vel; }
	void setVel(int k) { vel = k; }
	MovingDir getDir() { return direction; }
    virtual void move(MovingDir) = 0;
};

class TrafficLight : public Position
{
	int count, time_red, time_green;
	bool isRed, isGreen;
public:
	TrafficLight(int PosX, int PosY, int timer_red, int timer_green) 
	{ 
		x = PosX;
		y = PosY;
		time_red = timer_red;
		count = time_green = timer_green;
		isRed = false;
	}
	bool isStop() { return (isRed); }
	bool sameLine(const MovingObject *temp)
	{
		if (y >= temp->y && y < temp->y + temp->curImg().getHeight() ||
			temp->y >= y && temp->y < y + trafficLight.getHeight())
			return true;
		return false;
	}
	void run()
	{
		if (count == 0)
		{
			count = (isRed) ? time_green : time_red;
			isRed = (isRed == true) ? false : true;
		}
		else
			count--;
	}
};
#endif // !_OBJECT
