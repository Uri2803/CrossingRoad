#pragma once
#ifndef _OBJECT
#define _OBJECT_
#include "Animation.h"

enum MovingDir { left_, right_, up_, down_, idle_ }; // for moving I think :3
class Object : public Position
{
	Animation anim;
	MovingDir direction;
public:
	picture curImg() { return anim.getCurFrame(); }
	void setAnim(const Animation);
	void playAnim();
	Object();
	~Object();
};
#endif // !_OBJECT
