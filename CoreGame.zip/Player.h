#pragma once
#ifndef _PLAYER_
#define _PLAYER_
#include "Vehicle.h"
#include "Animal.h"
#define MAX_LEVEL 4;
class Player : public MovingObject
{
	int health, level;
public:
	Player();
	Player(Position, int health_, int level_);
	int getHealth() { return health; }
	int getLevel() { return level; }
	bool isDead() { return (health == 0); }
	bool isFinish() { return (level == 4); }
	bool isImpact(const MovingObject*);
	void move(MovingDir);
	//string getName() { return "Player"; }
};
#endif // !_PLAYER_