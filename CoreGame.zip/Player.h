#pragma once
#ifndef _PLAYER_
#define _PLAYER_
#include "Vehicle.h"
#include "Animal.h"
#define MAX_LEVEL 4;
class Player : public MovingObject
{
	int health, level;
public:
	Player();
	Player(Position);
	bool isDead() { return (health == 0); }
	bool isFinish() { return (level == 4); }
	bool isImpact(const Vehicle*);
	bool isImpact(const Animal*);
	void move(MovingDir);
};
#endif // !_PLAYER_