#pragma once
#ifndef _PLAYER_
#define _PLAYER_
#include "Vehicle.h"
class Player : public Object
{
	int vel;
public:
	Player();
	Player(Position, Animation);
	int velocity() { return vel; }
	void move(MovingDir dir); // avoid moving in free time
	// bool isImpact(const Vehicle*&);
};
#endif // !_PLAYER_
