#include "Object.h"
void Object::setAnim(const Animation animation)
{
	anim = animation;
}
void Object::playAnim()
{
	anim.play();
}
//void MovingObject::move(MovingDir dir)
//{
//	if (dir != idle_) // playAnim normal else play Anim idle
//		playAnim(); // should we play Animation when move or just play it all the time ?
//	if (dir == up_)
//		y -= vel;
//	if (dir == down_)
//		y += vel;
//	if (dir == left_)
//		x -= vel;
//	if (dir == right_)
//		x += vel;
//}