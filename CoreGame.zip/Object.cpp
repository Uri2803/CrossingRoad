#include "Object.h"
Object::Object()
{

}

Object::~Object()
{
}

void Object::setAnim(const Animation animation)
{
	anim = animation;
}
void Object::playAnim()
{
	anim.play(Position(x, y));
}