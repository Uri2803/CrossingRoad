#include "Object.h"
void Object::setAnim(const Animation animation)
{
	anim = animation;
}
void Object::playAnim()
{
	anim.play();
}