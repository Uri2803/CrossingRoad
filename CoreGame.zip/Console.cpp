#include "Console.h"
MyConsole::MyConsole()
{
	ConOut = GetStdHandle(STD_OUTPUT_HANDLE);
	ConIn = GetStdHandle(STD_INPUT_HANDLE);
}
MyConsole::~MyConsole()
{
	delete[] screenBuffer;
	screenBuffer = nullptr;
}
void MyConsole::showCursor()
{
	CONSOLE_CURSOR_INFO Info;
	Info.bVisible = true;
	Info.dwSize = 20;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &Info);
}
void MyConsole::noCursor()
{
	CONSOLE_CURSOR_INFO Info;
	Info.bVisible = FALSE;
	Info.dwSize = 20;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &Info);
}
void MyConsole::BuildConsole(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE) // create and construct
{
	ConOut = GetStdHandle(STD_OUTPUT_HANDLE);
	ConIn = GetStdHandle(STD_INPUT_HANDLE);
	ScreenWidth = width_;
	ScreenHeight = height_;

	Window = { 0, 0, (short)(ScreenWidth), (short)(ScreenHeight) };
	SetConsoleWindowInfo(ConOut, TRUE, &Window);

	CONSOLE_FONT_INFOEX cfi;
	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = 0;
	cfi.dwFontSize.Y = fontSize;
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = FW_NORMAL;
	wcscpy_s(cfi.FaceName, L"Consolas");
	SetCurrentConsoleFontEx(ConOut, false, &cfi);

	SetConsoleWindowInfo(ConOut, TRUE, &Window);

	COORD screen_init = { short(ScreenWidth), short(ScreenHeight) };
	SetConsoleScreenBufferSize(ConOut, screen_init);
	SetConsoleActiveScreenBuffer(ConOut);
	ShowWindow(GetConsoleWindow(), SW_MAXIMIZE); // for full screen;

	CONSOLE_SCREEN_BUFFER_INFOEX sbInfoEx;
	sbInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);
	GetConsoleScreenBufferInfoEx(ConOut, &sbInfoEx);
	sbInfoEx.dwSize.X = ScreenWidth;
	sbInfoEx.dwSize.Y = ScreenHeight;
	sbInfoEx.srWindow = { 0, 0, (short)ScreenWidth, (short)ScreenHeight };
	sbInfoEx.dwMaximumWindowSize = { (short)ScreenWidth, (short)ScreenHeight };
	SetConsoleScreenBufferInfoEx(ConOut, &sbInfoEx);

	DWORD mode;
	GetConsoleMode(ConOut, &mode);
	mode &= ~ENABLE_WRAP_AT_EOL_OUTPUT;
	SetConsoleMode(ConOut, mode);

	SetConsoleMode(ConIn, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);
	screenBuffer = new CHAR_INFO[ScreenWidth * ScreenHeight];
	noCursor();

}
void MyConsole::GameThread() // this one is for test
{
	int x = 5, y = 5;
	short carCol = COLOUR::BG_YELLOW | FG_RED;
	while (true)
	{
		while (true) // double run to make it faster, maybe :3
		{
			char key = getch();
			if (key == 'd')
			{
				x++;
				for (int i = 0; i < car1.getHeight(); i++)
				{
					wstring space = L" ";
					for (int j = 0; j < car1.getWidth(); j++)
						space += ' ';
					drawString(x - 1, y + i, space, carCol);
				}
			}
			if (key == 'a')
			{
				x--;
				for (int i = 0; i < car1.getHeight(); i++)
				{
					wstring space = L" ";
					for (int j = 0; j < car1.getWidth(); j++)
						space += ' ';
					drawString(x + 1, y + i, space, carCol);
				}
			}
			if (key == 'w')
			{
				y--;
				for (int i = 0; i < car1.getHeight(); i++)
				{
					wstring space = L" ";
					for (int j = 0; j < car1.getWidth(); j++)
						space += ' ';
					drawString(x, y + i + 1, space, carCol);
				}
			}
			if (key == 's')
			{
				y++;
				for (int i = 0; i < car1.getHeight(); i++)
				{
					wstring space = L" ";
					for (int j = 0; j < car1.getWidth(); j++)
						space += ' ';
					drawString(x, y + i - 1, space, carCol);
				}
			}
			if (key == 'q') // for debug and things
				break;
			drawPicture(x, y, car1, carCol);
			WriteConsoleOutputW(ConOut, screenBuffer, { short(ScreenWidth), short(ScreenHeight) }, { 0, 0 }, &Window);
		}
	}
}
void MyConsole::addChar(Position pos, wchar_t k, short col)
{
	if (pos.x >= 0 && pos.x < getWidth() && pos.y >= 0 && pos.y < getHeight())
	{
		screenBuffer[pos.x + pos.y * getWidth()].Char.UnicodeChar = k;
		screenBuffer[pos.x + pos.y * getWidth()].Attributes = col;
	}
}
void MyConsole::validate(int &x, int &y)
{
	if (x < 0) x = 0;
	if (x >= getWidth()) x = getWidth();
	if (y < 0) y = 0;
	if (y >= getHeight()) y = getHeight();
}
void MyConsole::FillArea(Position pos, wchar_t k, int width, int height, short col)
{
	validate(pos.x, pos.y);
	validate(width, height);
	for (int y = 0; y < height; y++)
		for (int x = 0; x < width; x++)
			addChar(Position(pos.x + x,pos.y + y), k, col);
}
void MyConsole::drawConsole() 
{ 
	WriteConsoleOutputW(ConOut, screenBuffer, { short(ScreenWidth), short(ScreenHeight) }, { 0, 0 }, &Window); 
}
void MyConsole::drawPicture(int x, int y, const picture k, short color)
{
	for (int i = 0; i < k.getHeight(); i++)
		drawString(x, y + i, k.getImg()[i], color);
}
void MyConsole::drawString(int x, int y, wstring k, short color)
{
	for (int i = 0; i < k.size(); i++)
	{
		screenBuffer[x + i + y * ScreenWidth].Char.UnicodeChar = k[i];
		screenBuffer[x + i + y * ScreenWidth].Attributes = color;
	}
}
void MyConsole::setFontSize(int xSize, int ySize)
{

}