﻿#pragma once
#ifndef _GAME_
#define _GAME_
#include <iostream>
#include "Music.h"
#include <fstream>
#include "Console.h"
#include "Player.h"
// #include "Vehicle.h"
// #include "Animal.h"
using namespace std;
enum GameState { mainMenu, playMenu, optionMenu, newGame, loadGame, playGame, pauseMenu, credits, exitGame, editSave };
class Game : private MyConsole, private Music
{
	short bgColor;
	bool playing;
	GameState state;
	thread* scene;
	bool OnMusic;
	vector<string> saveFile;
	Player* player;
	// vector<Vehicle*> vehicleList;
	// vector<Animal*> animalList;
public:
	Game();
	Game(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE);
	void Start();
	void readSaveFile();
	void drawBorder();
	void drawGame();
	void drawNewGame();
	void drawMenu();
	void drawMenuPlay();
	void drawMenuOption();
	void drawMenuCredit();
	void drawLoadMenu();
	void drawEditSave();
	void drawPauseMenu();
	void updatePosPlayer(char);
	// void updatePosObject();
	void drawPlayer();
	bool validMove(picture ,Position, int, MovingDir);
	~Game();
};
#endif // !_GAME_
