﻿#pragma once
#ifndef _GAME_
#define _GAME_
#include <iostream>
#include "Music.h"
#include <fstream>
#include "Console.h"
#include "Player.h"

//#include "Vehicle.h"
//#include "Animal.h"
using namespace std;
enum GameState { mainMenu, playMenu, optionMenu, newGame, loadGame, playGame, pauseMenu, credits, exitGame, editSave };
class Game : private MyConsole
{
	short bgColor;
	GameState state;
	vector<string> saveFile;
	Player* player;

	// vector<MovingObject*> obstacles; // biggest container
	vector<TrafficLight*> lights;
	vector<Vehicle*> vehicleList;
	vector<Animal*> animalList;
public:
	Game();
	Game(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE);
	void Start();
	void readSaveFile();
	void drawBorder();
	void drawGame();
	void drawNewGame();
	void drawMenu();
	void drawMenuPlay();
	void drawMenuOption();
	void drawMenuCredit();
	void drawLoadMenu();
	void drawEditSave();
	void drawPauseMenu();
	void updatePosPlayer(char);
	void updatePosObject(); // for both vehicle and animal to make a move
	void drawPlayer();
	void drawObject();
	bool validMove(picture ,Position, int, MovingDir);
	void CreatePlayer() 
	{ 
		player = new Player(); 
		player->x = (getWidth() - 30) / 2 - player->curImg().getWidth();
		player->y = getHeight() - player->curImg().getHeight() - 1;
	}
	void LoadPlayer(Position k, int health, int level) 
	{ 
		player = new Player(k, health, level); 
	}
	void Level1()
	{
		// line 1
		vehicleList.push_back(new Truck(10, 5, left_, 1));
		vehicleList.push_back(new Car(50, 6, left_, 1));
		animalList.push_back(new Deer(90, 5, left_, 1));

		// line 2
		vehicleList.push_back(new Car(10, 16, right_, 2));
		animalList.push_back(new Deer(50, 15, right_, 2));
		animalList.push_back(new Deer(90, 15, right_, 2));

		lights.push_back(new TrafficLight(170, 15, 1000, 5000)); // (x, y, time for red light, time for green light ) count as millisecond

		// line 3 maybe 
		vehicleList.push_back(new Truck(10, 25, left_, 5));
		vehicleList.push_back(new Car(50, 26, left_, 2));
		vehicleList.push_back(new Car(90, 26, left_, 2));

		lights.push_back(new TrafficLight(5, 25, 2000, 3000)); // dont put 2 lights on 1 line with different timer :>, not funny

		// line 4
		vehicleList.push_back(new Truck(10, 35, right_, 4));
		vehicleList.push_back(new Car(50, 36, right_, 4));
		vehicleList.push_back(new Truck(90, 35, right_, 4));

		lights.push_back(new TrafficLight(170, 35, 3000, 4000)); // dont put 2 lights on 1 line with different timer :>, not funny
	}
	void Level2()
	{

	}
	void Level3()
	{

	}
	void Level4()
	{

	}
	~Game();
};
#endif // !_GAME_
