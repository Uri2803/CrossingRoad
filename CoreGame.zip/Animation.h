#pragma once
#ifndef _ANIMATION_
#define _ANIMATION_
#include "Console.h"
#include "Pictures.h"
class Animation : private MyConsole
{
    int track, cooldown, max_cooldown;
    short color;

public:
    vector<picture> frames;
    Animation();
    Animation(vector<picture> list, int duration, short col = COLOUR::BG_WHITE | FG_DARK_YELLOW);
    void play(Position);
    picture getCurFrame() { return frames[track]; }
};
const Animation carAnimator(carAnim, 300, COLOUR::BG_WHITE | FG_DARK_MAGENTA);
#endif // !_ANIMATION_
