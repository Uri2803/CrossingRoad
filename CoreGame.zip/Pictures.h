﻿#pragma once
#ifndef PICTURE
#define PICTURE
#include <iostream>
#include <vector>
using namespace std;
class Position
{
public:
    int x, y;
    Position(int PosX, int PosY)
    {
        x = PosX;
        y = PosY;
    }
};
class picture
{
    vector<wstring> image;
    int width, height;

public:
    picture() 
    {
        width = 0;
        height = 0;
    }
    picture(vector<wstring> temp);
    int getWidth() const { return width; } // make sure that they are const
    int getHeight() const { return height; }
    vector<wstring> getImg() const { return image; }
};
//class Animation : public Position
//{
//    int track, cooldown, max_cooldown;
//    short backColor, textColor;
//    MovingDir direction;
//
//public:
//    vector<picture> frames;
//    Animation();
//    Animation(vector<picture> list, int duration, Position posXY, int backgroundColor, int TextColor, MovingDir dir = idle_)
//    {
//        frames = list;
//        max_cooldown = duration;
//        cooldown = 0;
//        x = posXY.x;
//        y = posXY.y;
//        backColor = backgroundColor;
//        textColor = TextColor;
//        track = 0;
//        direction = dir;
//    }
//    void play();
//    picture getCurFrame() { return frames[track]; }
//};
// this is how we made model or initialized things
// special type of animation
const picture car1(vector<wstring>{
    L"    _____",
    L" __╱_|___╲____",
    L"╰(+)───────(+)╯"});

const picture car2(vector<wstring>{
    L"   ____",
    L"__/_|__\\----__",
    L"|(x)-------(x)|"});

const picture ship1(vector<wstring>{
    L"     //     ______[_]======   ______",
    L"____[T]____|__|     |________/     /",
    L"\\_________________________________/ "});

const picture intro1(vector<wstring>{
    L" __        __",
    L"/  \\______/  \\",
    L"| (.)     (.)|",
    L"|  ________  |",
    L"|             |",
    L"\\____________/"});

const picture intro2(vector<wstring>{
    L" __        __",
    L"/  \\______/  \\",
    L"| (.)     (.)|",
    L"|  ________  |",
    L"|  \\______/  |",
    L"\\____________/"});

const picture carAttack2(vector<wstring>{
    L"  ==={MG]___",
    L" ____/__|__\\__",
    L"|(x)=======(x)|"});

const picture bullet1(vector<wstring>{L">=>"});

const picture octo2(vector<wstring>{
    L"  ________ ",
    L" /        \\",
    L" | __  __ |",
    L" \\        /",
    L" /        \\",
    L"/~/\\~/\\~/\\~\\"});

const picture octo1(vector<wstring>{
    L"  ________ ",
    L" /        \\",
    L" | ()  () |",
    L" \\        /",
    L" /        \\",
    L"/_/\\_/\\_/\\_\\"});

const picture pum1(vector<wstring>{
    L"  ___________ || ___________ ",
    L" /           \\||/           \\",
    L"/             \\/             \\",
    L"|       /\\          /\\       |",
    L"|      /__\\        /__\\      |",
    L"|             /\\             |",
    L"|            /__\\            |",
    L"|    _________    _______    |",
    L"\\    \\   __   \\__/ __   /    /",
    L" \\    \\_/  \\______/  \\_/    /",
    L"   ------------------------"});

const picture pum_2(vector<wstring>{
    L"  ___________ || ___________ ",
    L" /           \\||/           \\",
    L"/             \\/             \\",
    L"|       /\\          /\\       |",
    L"|      /__\\        /__\\      |",
    L"|             /\\             |",
    L"|            /__\\            |",
    L"|    \\                 /     |",
    L"\\     -----------------      /",
    L" \\      \\/        \\/        /",
    L"   ------------------------"});
#endif