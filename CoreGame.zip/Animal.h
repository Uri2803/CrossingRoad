#pragma once
#ifndef _ANIMAL_
#define _ANIMAL_
#include "Object.h"
class Animal : public MovingObject
{
public:
	//Animal();
};
class Bird : public Animal
{
public:
	//Bird();
};
class Leopard : public Animal
{
public:
	//Leopard();
};
#endif // !_ANIMAL_
