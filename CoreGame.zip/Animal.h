#pragma once
#ifndef _ANIMAL_
#define _ANIMAL_
#include "Object.h"
class Animal : private Object
{
public:
	Animal() { }
};
#endif // !_ANIMAL_
