#include "Player.h"
Player::Player()
{
	x = 0;
	y = 0;
	setVel(5);
	setAnim(introAnimator);
}
Player::Player(Position pos)
{
	x = pos.x;
	y = pos.y;
	setVel(5);
	setAnim(introAnimator);
}
void Player::move(MovingDir dir)
{
	if (dir == left_) x -= vel;
	else if (dir == right_) x += vel;
	else if (dir == up_) y -= vel;
	else if (dir == down_) y += vel;
	playAnim(); // ??
}
bool Player::isImpact(const Vehicle* car)
{
	if (x + curImg().getWidth() - 1 >= car->x && x <= car->x + car->curImg().getWidth() - 1 &&
		y + curImg().getHeight() - 1 >= car->y && y <= car->y + car->curImg().getHeight() - 1)
		return true;
	return false;
}
bool Player::isImpact(const Animal* bird)
{
	
	return true;
}