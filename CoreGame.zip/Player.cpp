#include "Player.h"
Player::Player()
{
	x = 0;
	y = 0;
	vel = 3;
}
Player::Player(Position pos, Animation animation)
{
	vel = 3;
	x = pos.x;
	y = pos.y;
	setAnim(animation);
}
void Player::move(MovingDir dir)
{
	if (dir == up_)
		y -= vel;
	if (dir == down_)
		y += vel;
	if (dir == left_)
		x -= vel;
	if (dir == right_)
		x += vel;
}
//bool Player::isImpact(const Vehicle*& car)
//{
//	return true;
//}