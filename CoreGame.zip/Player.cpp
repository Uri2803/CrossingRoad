#include "Player.h"
Player::Player()
{
	x = 0;
	y = 0;
	setVel(5);
	setAnim(dancingAnimator);
	health = 100;
	level = 1;
}
Player::Player(Position pos, int health_, int level_)
{
	x = pos.x;
	y = pos.y;
	setVel(5);
	setAnim(dancingAnimator);
	health = health_;
	level = level_;
}
void Player::move(MovingDir dir)
{
	if (dir == left_) x -= vel;
	else if (dir == right_) x += vel;
	else if (dir == up_) y -= vel;
	else if (dir == down_) y += vel;
	playAnim(); // ??
}
bool Player::isImpact(const MovingObject* nah)
{
	if (x + curImg().getWidth() - 1 >= nah->x && x <= nah->x + nah->curImg().getWidth() - 1 &&
		y + curImg().getHeight() - 1 >= nah->y && y <= nah->y + nah->curImg().getHeight() - 1)
	{
		health -= 10;
		return true;
	}
	return false;
}