#include "Player.h"
Player::Player()
{
	x = 0;
	y = 0;
	setVel(3);
	setAnim(carAnimator);
}
Player::Player(Position pos, const Animation animation)
{
	x = pos.x;
	y = pos.y;
	setVel(3);
	setAnim(animation);
}
void Player::move(MovingDir dir)
{
	if (dir == left_) x -= vel;
	else if (dir == right_) x += vel;
	else if (dir == up_) y -= vel;
	else if (dir == down_) y += vel;
	playAnim();
}
bool Player::isImpact(const Vehicle*& car)
{

	return true;
}
bool Player::isImpact(const Animal*& car)
{
	
	return true;
}