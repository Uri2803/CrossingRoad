#pragma once
#ifndef _VEHICLE_
#define _VEHICLE_
#include "Object.h"
// #include "Player.h"
class Vehicle : public Object
{
public:
	Vehicle();
	~Vehicle();
	// bool hitPlayer(const Player*& target);
};

//Vehicle::Vehicle()
//{
//}
//
//Vehicle::~Vehicle()
//{
//}

//bool Vehicle::hitPlayer(const Player*& target)
//{
//	return true;
//}
#endif // !_VEHICLE_
