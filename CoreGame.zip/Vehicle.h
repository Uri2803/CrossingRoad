#pragma once
#ifndef _VEHICLE_
#define _VEHICLE_
#include "Object.h"
class Vehicle : public MovingObject
{
public:
	Vehicle()
	{

	}
	virtual void move(MovingDir) = 0;
};
class Car : public Vehicle
{
public:
	Car(int x_, int y_)
	{
		anim = carAnimator;
		direction = left_;
		x = x_;
		y = y_;
	}
	void move(MovingDir dir)
	{
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
		playAnim();
	}
};
class Truck : public Vehicle
{
public:
	Truck(int x_, int y_)
	{
		anim = pumAnimator;
		direction = right_;
		x = x_;
		y = y_;
	}
	void move(MovingDir dir)
	{
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
		playAnim();
	}
};

#endif // !_VEHICLE_
