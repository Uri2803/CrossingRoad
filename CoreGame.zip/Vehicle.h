#pragma once
#ifndef _VEHICLE_
#define _VEHICLE_
#include "Object.h"
class Vehicle : public MovingObject
{
public:
	Vehicle()
	{
		vel = 1; // for all vehicles
	}
	virtual void move(MovingDir) = 0;
};
class Car : public Vehicle
{
public:
	Car(int x_, int y_, MovingDir dir)
	{
		anim = carAnimator;
		direction = dir;
		x = x_;
		y = y_;
	}
	void move(MovingDir dir)
	{
		if (mov_count == 0)
		{
			mov_count = mov_timer;
			if (dir == left_) x -= vel;
			else if (dir == right_) x += vel;
			else if (dir == up_) y -= vel;
			else if (dir == down_) y += vel;
		}
		else
			mov_count--;
		// playAnim();
	}
};
class Truck : public Vehicle
{
public:
	Truck(int x_, int y_, MovingDir dir)
	{
		anim = octoAnimator;
		direction = dir;
		x = x_;
		y = y_;
	}
	void move(MovingDir dir)
	{
		if (mov_count == 0)
		{
			mov_count = mov_timer;
			if (dir == left_) x -= vel;
			else if (dir == right_) x += vel;
			else if (dir == up_) y -= vel;
			else if (dir == down_) y += vel;
		}
		else
			mov_count--;
		// playAnim();
	}
};

#endif // !_VEHICLE_
