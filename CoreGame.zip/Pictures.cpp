#include "Pictures.h"
picture::picture(vector<wstring> temp)
{
	image = temp;
	height = temp.size();
	width = 0;
	for (auto i : temp)
		if (i.size() > width)
			width = i.size();
}