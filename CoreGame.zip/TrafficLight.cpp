#include "TrafficLight.h"
TrafficLight::TrafficLight(int PosX, int PosY, int timer_red, int timer_green, bool isRed_, int curTime)
{
	x = PosX;
	y = PosY;
	time_red = timer_red;
	count = (curTime != 0) ? curTime : timer_green;
	time_green = timer_green;
	isRed = isRed_;
}
bool TrafficLight::sameLine(const MovingObject* temp)
{
	if (y >= temp->y && y < temp->y + temp->curImg().getHeight() ||
		temp->y >= y && temp->y < y + trafficLight.getHeight())
		return true;
	return false;
}
void TrafficLight::run()
{
	if (count == 0)
	{
		count = (isRed) ? time_green : time_red;
		isRed = (isRed == true) ? false : true;
	}
	else
		count--;
}