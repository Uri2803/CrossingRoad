#pragma once
#ifndef _MUSIC_
#define _MUSIC_
#include <iostream>
#include <Windows.h>
#pragma comment(lib, "Winmm.lib")
using namespace std;
class Music
{
public:
	Music()
	{
		mciSendString(LPTSTR("open \"Music/BlueDream.mp3\" type mpegvideo alias background"), NULL, 0, NULL);
	}
	void playTheme() 
	{ 
		mciSendString(LPTSTR("play background repeat"), NULL, 0, NULL); 
	}
	void playKeyBoardSound() 
	{ 
		mciSendString(LPTSTR("open \"Music/beep.mp3\" type mpegvideo alias keyboard"), NULL, 0, NULL);
		mciSendStringA(LPTSTR("play keyboard from 10"), NULL, 0, NULL);
	}
	void playHitSound()
	{
		mciSendString(LPTSTR("open \"Music/HitSound.mp3\" type mpegvideo alias hitSound"), NULL, 0, NULL);
		// mciSendStringA(LPTSTR("setaudio hitSound volume to 50000"), NULL, 0, NULL);
		mciSendStringA(LPTSTR("play hitSound from 0"), NULL, 0, NULL);
	}
	void pause() { mciSendString(LPTSTR("pause background"), NULL, 0, NULL); }
	void close() { mciSendString(LPTSTR("close background"), NULL, 0, NULL); }
	void newPlay()
	{
		close();
		mciSendString(LPTSTR("open \"Music/BlueDream.mp3\" type mpegvideo alias background"), NULL, 0, NULL);
		playTheme();
	}
};
#endif // !_MUSIC_