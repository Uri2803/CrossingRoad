#include "Animation.h"
Animation::Animation()
{
	max_cooldown = 0;
}
Animation::Animation(vector<picture> list, int duration, short col)
{
	frames = list;
	max_cooldown = duration;
	cooldown = 0;
	color = col;
	track = 0;
}

void Animation::play(Position pos)
{
	if (cooldown == 0)
	{
		cooldown = max_cooldown;
		if (track < frames.size())
		{
			drawPicture(pos.x, pos.y, frames[track], color);
			track++;
			if (track == frames.size())
				track = 0;
		}
	}
	else
		cooldown--;
}